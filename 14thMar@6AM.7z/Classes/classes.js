/*
    - we know only declarations, don't know implementations then we will choose
      interfaces.

    - implementation provided by either JSON/Classes.

    - we will define interface by using "interface" keyword.

    - we will implement interfaces by using "implements" keyword
*/
;
;
;
var my_class = /** @class */ (function () {
    function my_class() {
    }
    my_class.prototype.fun_one = function () {
        return "I am from fun one !!!";
    };
    ;
    my_class.prototype.fun_two = function () {
        return "I am from fun two !!!";
    };
    ;
    my_class.prototype.fun_three = function () {
        return "I am from fun three !!!";
    };
    ;
    return my_class;
}());
;
var obj = new my_class();
document.write(obj.fun_one() + "<br>" +
    obj.fun_two() + "<br>" +
    obj.fun_three());
