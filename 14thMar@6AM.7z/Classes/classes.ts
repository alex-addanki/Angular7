/*
    - we know only declarations, don't know implementations then we will choose
      interfaces.

    - implementation provided by either JSON/Classes.

    - we will define interface by using "interface" keyword.

    - we will implement interfaces by using "implements" keyword
*/

/*
interface interface1{
    sub : string;
};
let obj:interface1 = {
    sub : "Angular8"
};
document.write( obj.sub );
*/

/*
interface interface1{
    sub:string;
    getSub():string;
};
let obj:interface1 = {
    sub : "Angular8",
    getSub : ()=>{ return obj.sub }
};
document.write( obj.sub + "<br>" + obj.getSub());
*/

/*
interface interface1{
    fun_one():string;
};
interface interface2 extends interface1{
    fun_two():string;
};
class my_class<interface2>{
    fun_one():string{
        return "I am from fun one !!!";
    }
    fun_two():string{
        return "I am from fun two !!!";
    };
};
let obj:my_class<interface2> = new my_class();
document.write( obj.fun_one() + "<br>" + obj.fun_two() );
*/




/*
interface interface1{
    fun_one():string;
};
interface interface2{
    fun_two():string;
};
class my_class<interface1,interface2>{
    fun_one():string{
        return "I am from fun one !!!";
    };
    fun_two():string{
        return "I am from fun two !!!";
    };
};
let obj:my_class<interface1,interface2> = new my_class();
document.write( obj.fun_one() + "<br>" + obj.fun_two() );
*/

/*
interface interface1{
    fun_one():string;
};
interface interface2 extends interface1{
    fun_two():string;
};
interface interface3 extends interface2{
    fun_three():string;
};
class my_class<interface3>{
    fun_one():string{
        return "I am from fun one !!!";
    };
    fun_two():string{
        return "I am from fun two !!!";
    };
    fun_three():string{
        return "I am from fun three !!!";
    };
};
let obj:my_class<interface3> = new my_class();
document.write( obj.fun_one() + "<br>" + 
                obj.fun_two() + "<br>" + 
                obj.fun_three() );
*/



interface interface1{
    fun_one():string;
};
interface interface2{
    fun_two():string;
};
interface interface3{
    fun_three():string;
};
class my_class<interface1,interface2,interface3>{
    fun_one():string{
        return "I am from fun one !!!";
    };
    fun_two():string{
        return "I am from fun two !!!";
    };
    fun_three():string{
        return "I am from fun three !!!";
    };
};
let obj:my_class<interface1,interface2,interface3> = new my_class();
document.write( obj.fun_one() + "<br>" +
                obj.fun_two() + "<br>" +
                obj.fun_three() );





































































