let obj:any = {
    angular : {
        wish  : "Good Morning...!"
    }
};
document.write( obj.angular.wish );