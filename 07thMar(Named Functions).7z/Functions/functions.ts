/*
    particular business logic called as function.
    functions are used to reuse the business logic.
    we can declare the functions by using "function" keyword.
    we have 5 types of functions
            1) Named Functions
            2) Anonymous Functions / Arrow Functions
            3) Rest Parameters in Functions
            4) Optional Parameters in Functions
            5) Default Parameters in Functions
*/

/* Named Functions 
            
    the function with the name called as Named Function.

    Syntax.
    ------
    //function definition
    function functionname(arguments with datatype):returntype{
        //Business Logic
    }

    //call the function
    functionname();
*/

/*
function fun_one():string{
    return "Welcome to Named Functions...!";
};
document.write( fun_one +"<br>");   //function definition
document.write( fun_one() );
*/
/*
function fun_one(arg1:string,arg2:string,arg3:string):void{
    document.write(arg1+"<==>"+arg2+"<==>"+arg3+"<br>");
};
fun_one("Angular8","NodeJS","MongoDB");
fun_one( "ReactJS","NodeJS","MySQL" );
*/
/*
function fun_one():any{
    return fun_two();
};
function fun_two():string{
    return "Welcome...!";
};
document.write( fun_one() );
*/




/*
function fun_one(arg1:any,arg2:any,arg3:any):any{
    document.write( arg1+"<==>"+arg2+"<==>"+arg3 +"<br>");
};
function fun_two():string{
    return "Angular8";
};
function fun_three():string{
    return "NodeJS";
};
function fun_four():string{
    return "MongoDB";
};
fun_one( fun_two(),fun_three(),fun_four() );
*/

/*
function fun_one():any{
    return fun_two;
};
function fun_two():string{
    return "Welcome...!";
};
document.write( fun_one()() );
*/
var my_array:Array<any> = [];
function fun_one():string{
    return "Welcome...!";
};
for(var i:number=0;i<5;i++){
    my_array.push( fun_one );
};
for(var i:number=0;i<my_array.length;i++){
    document.write( my_array[i]() );
};

















































































