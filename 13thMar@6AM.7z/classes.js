/*
class class_one{
    public fun_one():string{
        return "I am from class one !!!";
    };
};
class class_two extends class_one{
    public fun_two():string{
        return "I am from class two !!!";
    };
};
var obj:class_two = new class_two();
document.write( obj.fun_one() + "<br>" +
                obj.fun_two() );
*/
/*
class class_one{
    public fun_one():string{
        return "I am from class one !!!";
    };
};
class class_two extends class_one{
    public fun_two():string{
        return "I am from class two !!!";
    };
};
class class_three extends class_two{
    public fun_three():string{
        return "I am from class three !!!";
    };
};
var obj:class_three = new class_three();
document.write( obj.fun_one() + "<br>" + obj.fun_two() + "<br>" + obj.fun_three() );
*/
/*
class class_one{}
class class_two{}
class class_three extends class_one,class_two{}
*/
/*
class class_one{
    public add(num1:number,num2:number):number{
        return num1+num2;
    };
    public add(num1:number,num2:number,num3:number):number{
        return num1+num2+num3;
    };
};
*/
/*
class class_one{
    public dbFun():string{
        return "Data From MySQL Soon...!";
    };
};
class class_two extends class_one{
    public dbFun():string{
        return "Data From MongoDB Soon...!";
    };
};
var obj:class_two = new class_two();
document.write( obj.dbFun() );
*/
/*
   static:
   -------
        - for static members memory will be allotted in heap are.
        - we can access static members through class names.
        - we can't initilize static members via constructors.
        - we can't call static members via class references.
*/
var class_one = /** @class */ (function () {
    function class_one() {
    }
    // constructor(){
    //     class_one.sub = "Angular8";
    // };
    class_one.myFun = function () {
        return this.sub;
    };
    ;
    class_one.sub = "Angular8";
    return class_one;
}());
;
document.write(class_one.sub + "<br>" + class_one.myFun());
