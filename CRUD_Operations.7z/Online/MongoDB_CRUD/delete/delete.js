module.exports = require("../common/imports").express.Router().post("/",(req,res)=>{
    let mongodb = require("../common/imports").mongodb;
    var nareshIT = mongodb.MongoClient;
    nareshIT.connect("mongodb://localhost:27017/online",(err,db)=>{
        db.collection("employees").deleteOne({"e_id":req.body.e_id},(err,result)=>{
            if(err){
                res.send({"delete":"fail"});
            }else{
                res.send({"delete":"success"});
            }
        });
    });
});