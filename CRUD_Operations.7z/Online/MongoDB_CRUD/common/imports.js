module.exports = {
    express     :   require("express"),
    cors        :   require("cors"),
    bodyparser  :   require("body-parser"),
    mongodb     :   require("mongodb")
};