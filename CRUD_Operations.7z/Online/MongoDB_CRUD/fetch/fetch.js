module.exports = require("../common/imports").express.Router().get("/",(req,res)=>{
    let mongodb = require("../common/imports").mongodb;
    let nareshIT = mongodb.MongoClient;
    nareshIT.connect("mongodb://localhost:27017/online",(err,db)=>{
        db.collection("employees").find().toArray((err,array)=>{
            res.send(array);
        });
    });
});