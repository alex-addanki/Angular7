module.exports = require("../common/imports").express.Router().post("/",(req,res)=>{
    let mssql = require("../common/imports").mssql;
    mssql.connect(require("../config/db_properties"),(err)=>{
        if(err){
            console.log("Error...!");
        }else{
            let queries = new mssql.Request();
            queries.query("update employees set e_name='"+req.body.e_name+"',e_sal="+req.body.e_sal+" where e_id="+req.body.e_id,(err,result)=>{
                if(err){
                    res.send({"update":"fail"});
                }else{
                    res.send({"update":"success"});
                }
                mssql.close();
            });
        }
    });
});