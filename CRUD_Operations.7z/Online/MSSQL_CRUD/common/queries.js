module.exports = {
    getConnection       :       ()=>{
        let connection = require("./imports").mssql.connect(require("../config/db_properties")); 
        return connection;
    },
    fetch                :      (res,queries)=>{
        queries.query("select * from employees",(err,records)=>{
            res.send(records);
        });
    },
    insert               :      (req,res,queries)=>{
            queries.query("insert into employees values("+req.body.e_id+",'"+req.body.e_name+"',"+req.body.e_sal+")",(err,result)=>{
                if(err){
                    res.send({"insert":"fail"});
                }else{
                    res.send({"insert":"success"});
                }
            });
    },
    update               :      (req,res,queries)=>{
        queries.query("update employees set e_name='"+req.body.e_name+"',e_sal="+req.body.e_sal+" where e_id="+req.body.e_id,(err,result)=>{
            if(err){
                res.send({"update":"fail"});
            }else{
                res.send({"update":"success"});
            }
        });
    },
    delete               :      (req,res,queries)=>{
        queries.query("delete from employees where e_id="+req.body.e_id,(err,result)=>{
            if(err){
                res.send({"delete":"fail"});
            }else{
                res.send({"delete":"success"});
            }
        });
    }
};