module.exports = {
    express     :    require("express"),
    mssql       :    require("mssql"),
    cors        :    require("cors"),
    bodyparser  :    require("body-parser")
};