module.exports = require("../common/imports").express.Router().get("/",(req,res)=>{
    let mssql = require("../common/imports").mssql;
    mssql.connect(require("../config/db_properties"),(err)=>{
        if(err){
            console.log("Error...!");
        }else{
            let queries = new mssql.Request();
           queries.query("select * from employees",(err,records)=>{
            if(err){
                res.send({"fetch":"fail"});
            }else{
                res.send(records.recordsets[0]);
            }
            mssql.close();
           });
        }
        
    });
});