module.exports = require("../common/imports").express.Router().post("/",(req,res)=>{
    let mssql = require("../common/imports").mssql;
    mssql.connect(require("../config/db_properties"),(err)=>{
        if(err){
            console.log("Error...!");
        }else{
            let queries = new mssql.Request();
            queries.query("insert into employees values("+req.body.e_id+",'"+req.body.e_name+"',"+req.body.e_sal+")",                                           (err,result)=>{
                if(err){
                    res.send({"insert":"fail"});
                }else{
                    res.send({"insert":"success"});
                }
                mssql.close();
            });
        }
    });
});