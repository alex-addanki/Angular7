module.exports = {
    user        :       "sa",
    password    :       "123",
    server      :       "localhost",
    database    :       "online"
};