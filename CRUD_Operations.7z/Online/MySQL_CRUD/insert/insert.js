var connection = require("../config/db_connection").getConnection();
connection.connect();
module.exports = require("express").Router().post("/",(req,res)=>{
    connection.query("insert into employees values("+req.body.e_id+",'"+req.body.e_name+"',"+req.body.e_sal+")",(err,result)=>{
        if(err){
            res.send({"insert":"fail"});
        }else{
            res.send({"insert":"success"});
        }
    });
});