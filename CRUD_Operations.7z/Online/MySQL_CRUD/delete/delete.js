var connection = require("../config/db_connection").getConnection();
connection.connect();
module.exports = require("express").Router().post("/",(req,res)=>{
    connection.query("delete from employees where e_id="+req.body.e_id,(err,result)=>{
        console.log(err);
        if(err){
            res.send({"delete":"fail"});
        }else{
            res.send({"delete":"success"});
        }
    });
});