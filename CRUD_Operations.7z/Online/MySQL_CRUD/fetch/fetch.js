var connection = require("../config/db_connection").getConnection();
connection.connect();
var express = require("express");
module.exports = express.Router().get("/",(req,res)=>{
    connection.query("select * from employees",(err,recordsArray,fields)=>{
        res.send(recordsArray);
    });
});