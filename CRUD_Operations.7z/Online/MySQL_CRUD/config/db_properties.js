module.exports = {
    user    :   "root",
    password:   "root",
    database:   "online",
    host    :   "localhost"
};