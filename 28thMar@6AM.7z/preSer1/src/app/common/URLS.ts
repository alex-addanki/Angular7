const COUNTRIES:string = "https://restcountries.eu/rest/v2/all";
export default COUNTRIES;