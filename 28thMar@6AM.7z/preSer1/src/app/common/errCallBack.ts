import { HttpErrorResponse } from "@angular/common/http";
export default  (err:HttpErrorResponse)=>{
    if(err.error instanceof Error){
        console.log("Client Side Error !!!");
    }else{
        console.log("Server Side Error !!!");
    }
};
