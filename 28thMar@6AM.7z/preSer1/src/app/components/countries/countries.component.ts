import { Component, OnInit } from '@angular/core';
import { CountriesService } from 'src/app/services/countries.service';
import errCallBack from "../../common/errCallBack";
@Component({
  selector: 'app-countries',
  templateUrl: './countries.component.html',
  styles: []
})
export class CountriesComponent implements OnInit {
  private result:any;
  constructor(private _service:CountriesService) { }
  ngOnInit() {
    this._service.getCountries().subscribe((posRes)=>{
        this.result = posRes;
    },errCallBack);
  }
}
