/*
//global variable
let data:number = 100;
//if block
if(true){
    //local variable
    let data:number = 200;
};
document.write(""+data);   //100
*/
/*
for(let i:number=0;i<10;i++){
};
document.write(""+i);   //Error
*/
/*
document.write(""+data);  //Error
let data:number = 100;
*/
/*
function fun_one(){
    var data:number = 100;
    let data1:number = 200;
    document.write( data+"<br>"+data1 );
};
fun_one();
*/
var URLS = "http://localhost:4200";
document.write(URLS);
