/*
function fun_one(arg1:string="Angular8",
                arg2:string="NodeJS",
                arg3:string="MongoDB"):void{
    if(arg1!=undefined){
        document.write(arg1+"<br>");
    };
    if(arg2!=undefined){
        document.write(arg2+"<br>");
    };
    if(arg3!=undefined){
        document.write(arg3+"<br>");
    };
    document.write("<hr>");
};
fun_one();
fun_one("ReactJS","NodeJS","MySQL");
fun_one("AngularJS",undefined,"SQLServer");
*/


/*
function fun_one(arg1:string,arg2:string="Hello"):void{
    if(arg1!=undefined && arg1!=null && arg1!=''){
        document.write(arg1+"<br>");
    }
    if(arg2!=undefined && arg2!=null && arg2!=''){
        document.write(arg2+"<br>");
    }
    document.write("<hr>");
};
fun_one("Welcome");
fun_one(null,"Welcome");
*/

// function fun_one(arg1:string):void{
//     arg1 = "Angular8";
// };
// fun_one();

/*
function fun_one(arg1:string,arg2:string="NodeJS",id:number,...arg3:string[]):void{
    let array_one:Array<any> = [];
    let array_two:Array<any> = [];
    let array_three:Array<any> = [];
    if(arg1 !=undefined && arg1!=null && arg1!=''){
        switch(id){
            case 1:
                array_one[0] = arg1;
                break;
            case 2:
                array_one[1] = arg1;
                break;
            case 3:
                array_one[2] = arg1;
                break;
            case 4:
                array_one[3] = arg1;
                break;
        }
    };


    if(arg2 !=undefined && arg2!=null && arg2!=''){
        switch(id){
            case 1:
                array_two[0] = arg2;
                break;
            case 2:
                array_two[1] = arg2;
                break;
            case 3:
                array_two[2] = arg2;
                break;
            case 4:
                array_two[3] = arg2;
                break;
        }
    };

    if(arg3 !=undefined && arg3!=null && arg3!=[]){
        switch(id){
            case 1:
                array_three[0] = arg3[0];
                break;
            case 2:
                array_three[1] = arg3[0];
                break;
            case 3:
                array_three[2] = arg3[0];
                break;
            case 4:
                array_three[3] = arg3[0];
                break;
        }
    };
    
    document.write(array_one[id-1]+"<==>"+array_two[id-1]+"<==>"+array_three[id-1]);
    document.write("<hr>");
    //document.write(array_one[1]+"<==>"+array_two[1]+"<==>"+array_three[1]);
};
fun_one(null,undefined,1,undefined);
fun_one("Angular8",null,2,undefined);
fun_one("AngularJS",undefined,3,"MySQL");
fun_one("ReactJS",'',4,"CassandraDB");
*/






function fun_one(arg1?:string):void{
    if(arg1!=undefined && arg1!=''){
        document.write(arg1+"<br>");
    };  
};
fun_one();
fun_one("Hello");




























































