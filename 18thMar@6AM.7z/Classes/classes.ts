/*
class class_one{
    private arg1:string;
    constructor(arg1:string){
        this.arg1 = arg1;
    }
    public getArg1():string{
        return this.arg1;
    };
};
class class_two extends class_one{
    constructor(){
        super("Angular8");
    };
};
var obj:class_two = new class_two();
document.write( obj.getArg1() );
*/
/*
class class_one{
    public fun_one():string{
        return "I am from fun one !!!";
    };
};
class class_two extends class_one{
    public fun_two():string{
        return super.fun_one();
    };
};
var obj:class_two = new class_two();
document.write( obj.fun_two() );
*/
/*
class class_one{
    readonly sub:string;
    constructor(){
        this.sub = "Angular8";
    };
};
var obj:class_one = new class_one();
document.write( obj.sub );
//obj.sub = "Angular8-Beta8";
*/
/*
let array_one:Array<number> = [10,20,30,40,50];
let array_two:Array<number> = [...array_one];
for(let i:number=0;i<array_two.length;i++){
    document.write( array_two[i] + "<br>");
};
*/


/*
let array_one = [10,20,30];
let array_two = [40,50,60];
let array_three = [...array_one,...array_two];
for(let i:number=0;i<array_three.length;i++){
    document.write( array_three[i] + "<br>");
};
*/



/*
let array_one = [10,20];
let array_two = [...array_one,30,40,...array_one];
for(let i:number=0;i<array_two.length;i++){
    document.write(array_two[i]+"<br>");
};  
*/

/*
let obj:any = {"e_id":111,"e_name":"e_one","e_sal":10000};
let obj1:any = {...obj};
document.write(JSON.stringify(obj1));
*/




/*
function fun_one(...arg1:Array<number>):any{
    if(arg1!=null){
        for(let i:number=0;i<arg1.length;i++){
            document.write(arg1[i]+"<br>");
        };
    };
};
fun_one();
fun_one(10);
fun_one(10,20,30,40,50);
*/

/*
function fun_one(...arg1,...arg2){}
    we will have only one spread operator, we can't have more than one spread
    operator
*/
function fun_one(arg1,...arg2){
    if(arg1!=undefined){
        document.write( arg1 + "<br>");
    }
    if( arg2 != null && arg2!=undefined && arg2!=[]){
        for(let i:number=0;i<arg2.length;i++){
            document.write( arg2[i] +"<br>");
        }
    }
};
fun_one(undefined);
fun_one(10);
fun_one(10,20);






































































