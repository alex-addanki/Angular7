import { Injectable } from "@angular/core";
@Injectable()
export class dbService{
    mysqlData():string{
        return "MySQL Data Soon...!";
    };
    mongodbData():string{
        return "MongoDB Data Soon...!";
    };
};