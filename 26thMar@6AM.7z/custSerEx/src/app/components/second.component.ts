import { Component } from "@angular/core";
import { dbService } from "../services/db.service";
@Component({
    selector:"second",
    templateUrl:"./second.component.html"
})
export class secondComponent{
    private result:string;
    constructor(private _service:dbService){}
    ngOnInit(){
        this.result = this._service.mongodbData();
    }
};