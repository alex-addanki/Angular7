import { Component } from "@angular/core";
@Component({
    selector:"second",
    templateUrl:"./second.component.html"
})
export class secondComponent{
    mongodbData():string{
        return "MongoDB Data Soon...!";
    };
};